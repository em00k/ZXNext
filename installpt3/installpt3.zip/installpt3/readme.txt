Replacement playpt3 v1
----------------------
##em00k - 04/07/2018##

This version will allow for a few more pt3/ts formats 
and loads the song to 32768 with a max size 
of 16kb.

Run the install.bas to allow you to easily swap the 
original playpt3 with the updated version.

This uses the updated PT3 TS play routines. 

;universal pt2'n'pt3 turbo sound player for zx spectrum
;(c)2004-2007 s.v.bulba <vorobey@mail.khstu.ru>
;specially for alco
;http://bulba.untergrund.net/ (http://bulba.at.kz/)

